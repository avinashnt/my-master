package com.marketlogic.api;

public class AlphaEncoding {

	/**
	 * Offset = args[0] Input String = args[1]
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		if (args.length == 0) {
			System.out.println("Please enter {0}=offset and {1}=input string");
			System.out.println("Valid offset values = 1 or -1");
			System.out.println("jar -jar alpha-encoding.jar 1 aZa123$%^hjuDF");
		}
		AlphaEncoding.encode(Integer.parseInt(args[0]), args[1]);
	}

	/**
	 * ASCII code for (A-Z) is (65-90) and (a-z) is 97-122
	 * 
	 * @param offset
	 * @param input
	 * @return
	 */
	public static String encode(int offset, String input) {
		StringBuilder output = new StringBuilder();
		System.out.println("Offset = " + offset);
		System.out.println("Input = " + input);

		if (offset == 1) {
			for (int i = 0; i < input.length(); i++) {
				if (Character.isLetter(input.charAt(i))) {
					if ('Z' == input.charAt(i))
						output.append('A');
					else if ('z' == input.charAt(i))
						output.append('a');
					else
						output.append((char) (input.charAt(i) + 1));
				} else {
					output.append(input.charAt(i));
				}
			}
			System.out.println("Success!! Output = " + output);
		} else if (offset == -1) {
			for (int i = 0; i < input.length(); i++) {
				if (Character.isLetter(input.charAt(i))) {
					if ('A' == input.charAt(i))
						output.append('Z');
					else if ('a' == input.charAt(i))
						output.append('z');
					else
						output.append((char) (input.charAt(i) - 1));
				} else {
					output.append(input.charAt(i));
				}
			}
			System.out.println("Success!! Output = " + output);
		} else {
			System.out.println("*** Error:Offset can be either 1 or -1 ***");
		}

		return output.toString();
	}

}
